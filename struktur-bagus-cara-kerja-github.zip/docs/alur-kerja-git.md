# Alur Kerja Git

1. `git init`
2. Tambahkan file: `git add`
3. Simpan perubahan: `git commit`
4. Hubungkan ke GitHub: `git remote add origin ...`
5. Push ke GitHub: `git push -u origin main`
