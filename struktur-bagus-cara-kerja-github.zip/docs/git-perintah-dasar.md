# Perintah Dasar Git

| Perintah | Fungsi |
|----------|--------|
| `git init` | Inisialisasi repository Git |
| `git clone` | Menyalin repo dari GitHub |
| `git add` | Menambahkan file ke staging |
| `git commit` | Menyimpan perubahan ke history |
| `git push` | Mengirim commit ke GitHub |
| `git pull` | Mengambil update terbaru dari GitHub |
| `git status` | Melihat status file |
