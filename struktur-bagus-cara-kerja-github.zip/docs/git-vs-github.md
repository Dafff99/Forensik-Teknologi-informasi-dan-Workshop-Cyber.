# Perbedaan Git dan GitHub

- **Git** adalah sistem kontrol versi.
- **GitHub** adalah layanan hosting repository Git di cloud.

Git bisa digunakan tanpa GitHub, tapi GitHub memudahkan kolaborasi.
