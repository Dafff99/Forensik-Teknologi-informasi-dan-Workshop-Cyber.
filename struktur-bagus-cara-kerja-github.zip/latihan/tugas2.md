# Tugas 2: Branching

1. Buat branch baru: `git checkout -b fitur-baru`
2. Edit file dan commit
3. Kembali ke main: `git checkout main`
4. Merge: `git merge fitur-baru`
