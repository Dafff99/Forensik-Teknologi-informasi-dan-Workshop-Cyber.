# Tugas 1: Commit Pertama

1. Tambahkan file baru
2. Lakukan `git add`
3. Lakukan `git commit -m "Commit pertama"`
